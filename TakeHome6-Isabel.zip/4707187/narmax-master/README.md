# An R library for nonlinear black-box system identification

For details please see and cite, if you use, the following publication

https://doi.org/10.1016/j.softx.2020.100495

Ayala, H. V. H., Gritti, M. and Coelho, L. S. An R library for nonlinear black-box system identification. SoftwareX, 2020 (to appear).

# Pull requests

A list of desired features can be found in the paper. They are all pending :)

