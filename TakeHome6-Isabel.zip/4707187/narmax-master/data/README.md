# Follow the links below for downloading the data

ftp://ftp.esat.kuleuven.be/pub/SISTA/data/thermic/heating_system.dat.gz
	
https://www.york.ac.uk/depts/maths/data/ts/ts22.dat

https://www.york.ac.uk/depts/maths/data/ts/ts23.dat

http://www.nonlinearbenchmark.org/FILES/BENCHMARKS/WIENERHAMMERSTEINPROCESS/WienerHammersteinFiles.zip

# Dump them in this folder and run the examples on the /examples folder

(all is explained in the manual, see the documentation/ folder, for description of the datasets and credits!)
